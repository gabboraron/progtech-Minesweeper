package akna;

/**
 * Programoz�si technol�gia 1.
 * 12. �rai feladat: Akna j�t�k, Main oszt�ly
 * @author Keszei �bel
 */
public class Main {
    public static void main(String[] args) {
        new MainWindow().setVisible(true);
    }
}
