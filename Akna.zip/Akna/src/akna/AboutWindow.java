package akna;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import static java.awt.BorderLayout.*;

/**
 * Programoz�si technol�gia 1.
 * 12. �rai feladat: Akna j�t�k, N�vjegy
 * @author Keszei �bel
 */
public class AboutWindow extends JDialog {
    private final JPanel closePanel, paddingPanel;
    private final JButton okButton;
    private final Box contentBox;
    
    private final Container contentPane = getContentPane();
    
    public AboutWindow(JFrame parent) {
        super(parent, "N�vjegy", true);

        contentPane.setLayout(new BorderLayout());
        
        contentBox = Box.createVerticalBox();
        contentBox.add(Box.createGlue());
        contentBox.add(new JLabel("Programoz�si technol�gia 1."));
        contentBox.add(new JLabel("12. �rai feladat: Akna j�t�k"));
        contentBox.add(new JLabel("Szerz�: Keszei �bel"));
        contentBox.add(Box.createGlue());

        okButton = new JButton("Bez�r�s");
        okButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                setVisible(false);
                dispose();
            }
        });
        
        closePanel = new JPanel();
        closePanel.add(okButton);
        
        paddingPanel = new JPanel();
        paddingPanel.add(Box.createHorizontalStrut(5));

        contentPane.add(contentBox, CENTER);
        contentPane.add(closePanel, SOUTH);
        contentPane.add(paddingPanel, WEST);
        
        getRootPane().setDefaultButton(okButton);

        setResizable(false);
        setSize(250, 150);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
}
