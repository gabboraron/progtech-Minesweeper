package akna;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import static java.awt.BorderLayout.*;
import static javax.swing.JOptionPane.*;

/**
 * Programoz�si technol�gia 1.
 * 12. �rai feladat: Akna j�t�k, Grafikus megjelen�t�s
 * @author Keszei �bel
 */
public class MainWindow extends JFrame {
    private final Container contentPane = getContentPane();
    private final JMenuBar menuBar;
    private final JMenu gameMenu, stepsMenu, helpMenu;
    private final JMenuItem newGame, pauseGame, exitGame, undoStep, aboutGame;
    private final JPanel gamePanel;

    private Model gameModel;
    private boolean gamePaused;
    
    public MainWindow() {
        gamePaused = false;
        
        contentPane.setLayout(new BorderLayout());

        menuBar = new JMenuBar();
        gameMenu = new JMenu("J�t�k");
        
        newGame = new JMenuItem("�j j�t�k");
        newGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                newGame();
            }
        });
        
        pauseGame = new JMenuItem("J�t�k meg�ll�t�sa");
        pauseGame.setEnabled(false);
        pauseGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                toggleGamePaused();
            }
        });
        
        exitGame = new JMenuItem("Kil�p�s");
        exitGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        
        gameMenu.add(newGame);
        gameMenu.add(pauseGame);
        gameMenu.addSeparator();
        gameMenu.add(exitGame);
        
        stepsMenu = new JMenu("L�p�sek");
        undoStep = new JMenuItem("Visszavon�s");
        undoStep.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                gameModel.undoLastStep();
                loadFromModel();
            }
        });
        
        stepsMenu.add(undoStep);
        stepsMenu.setEnabled(false);
        
        helpMenu = new JMenu("S�g�");
        aboutGame = new JMenuItem("N�vjegy");
        aboutGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AboutWindow(MainWindow.this).setVisible(true);
            }
        });
        helpMenu.add(aboutGame);

        menuBar.add(gameMenu);
        menuBar.add(stepsMenu);
        menuBar.add(helpMenu);
        contentPane.add(menuBar, PAGE_START);
        
        gamePanel = new JPanel();
        gamePanel.setLayout(new GridLayout(6, 6));

        contentPane.add(gamePanel, CENTER);
        
        setSize(450, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Akna j�t�k");
    }
    
    private void newGame() {
        pauseGame.setEnabled(true);
        stepsMenu.setEnabled(true);
        
        if (gamePaused)
            toggleGamePaused();
        
        gameModel = new Model();
        gamePanel.removeAll();
        for (int i = 0; i < 36; i++) {
            JButton button = new JButton();
            final int _i = i;
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (gameModel.stepTo(_i / 6, _i % 6)) {
                        displayGameLost();
                        return;
                    }
                    
                    loadFromModel();
                    
                    if (gameModel.isEndOfGame())
                        displayGameWon();
                }
            });
            gamePanel.add(button);
        }
        loadFromModel();
    }
    
    private void loadFromModel() {
        Point position = gameModel.getPosition();
        for (int i = 0; i < 36; i++) {
            JButton button = ((JButton)gamePanel.getComponent(i));
            if (position.x * 6 + position.y == i) {
                button.setText("X");
                button.setEnabled(false);
                button.setBackground(null);
            } else {
                ((JButton)gamePanel.getComponent(i)).setText("");
                button.setEnabled(true);
                button.setBackground(gameModel.alreadyStepped(i / 6, i % 6) ? Color.BLUE : null);
            }
        }
    }
    
    private void displayGameLost() {
        JOptionPane.showMessageDialog(this, "Felrobbant�l!", "J�t�k v�ge", WARNING_MESSAGE);
        newGame();
    }
    
    private void displayGameWon() {
        JOptionPane.showMessageDialog(this, "Gratul�lok, nyert�l!", "J�t�k v�ge", WARNING_MESSAGE);
        newGame();
    }
    
    private void toggleGamePaused() {
        if (gamePaused) {
            setTitle("Akna j�t�k");
            stepsMenu.setEnabled(true);
            pauseGame.setText("J�t�k meg�ll�t�sa");
            loadFromModel();
        } else {
            setTitle("Akna j�t�k - MEG�LL�TVA");
            stepsMenu.setEnabled(false);
            for (int i = 0; i < 36; i++)
                ((JButton)gamePanel.getComponent(i)).setEnabled(false);

            pauseGame.setText("J�t�k folytat�sa");
        }
        
        gamePaused = !gamePaused;
    }
}
