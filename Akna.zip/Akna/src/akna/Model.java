package akna;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Random;

/**
 * Programoz�si technol�gia 1.
 * 12. �rai feladat: Akna j�t�k, Modell
 * @author Keszei �bel
 */
public class Model {
    private final boolean[][] fields;
    private final Point position;
    private final ArrayList<Point> steps;
    
    private static final Random rng = new Random();
    
    public Model() {
        fields = new boolean[6][6];
        position = new Point(0, 0);
        steps = new ArrayList<>();
        steps.add(new Point(0, 0));
        
        int minesNum = rng.nextInt(2);
        for (int i = 0; i <= minesNum; i++) {
            int x, y;
            do {
                x = rng.nextInt(4) + 1;
                y = rng.nextInt(4) + 1;
            } while (fields[x][y]);
            
            fields[x][y] = true;
        }
    }
    
    public boolean canStepTo(int x, int y) {
        return Math.abs(position.x - x) == 0 && Math.abs(position.y - y) == 1 ||
               Math.abs(position.x - x) == 1 && Math.abs(position.y - y) == 0;
    }
    
    public boolean stepTo(int x, int y) {
        if (!canStepTo(x, y))
            return false;
        
        position.setLocation(x, y);
        steps.add((Point)position.clone());
        return fields[x][y];
    }
    
    public boolean isEndOfGame() {
        return position.equals(new Point(5, 5));
    }
    
    public Point getPosition() {
        return position;
    }
    
    public boolean alreadyStepped(int x, int y) {
        return steps.contains(new Point(x, y));
    }
    
    public void undoLastStep() {
        if (steps.size() <= 1)
            return;
        
        steps.remove(steps.size() - 1);
        position.setLocation(steps.get(steps.size() - 1));
    }
}
